#include <iostream>
using namespace std;
template <typename elmtype>
class CircularDynamicArray  {
public:
    CircularDynamicArray();
    elmtype &operator[](int i)  {
        return this -> array[(begin + i) % cap];
    }
    CircularDynamicArray(int s);
    ~CircularDynamicArray();
    void addFront(elmtype v);
    void addEnd(elmtype v);
    void delFront();
    void delEnd();
    int length();
    int capacity();
    int incArray();
    int decArray();
    void clear();
private:
    int len;
    int cap;
    int begin;
    int end;
    elmtype *array;
};
template <typename elmtype>
CircularDynamicArray<elmtype>::CircularDynamicArray()  {
    cap = 2;
    this -> array = new elmtype[this -> cap];
    len = 0;
    end = 0;
    begin = 0;
}
template <typename elmtype>
CircularDynamicArray<elmtype>::CircularDynamicArray(int s)  {
    this -> array = new elmtype[s];
    cap = s;
    len = s;
    begin = 0;
    end = s - 1;
}
template <typename elmtype>
CircularDynamicArray<elmtype>::~CircularDynamicArray()  {
    delete[] this -> array;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::addFront(elmtype v)  {
    if (cap == len)  {
        incArray();
    }
    begin--;
    if (abs(begin) != begin)  {
        begin = cap - 1;
    }
    this -> array[(begin) % cap] = v;
    len++;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::addEnd(elmtype v)  {
    if (cap == len)  {
        incArray();
    }
    this -> array[(begin + (len)) % cap] = v;
    end++;
    len++;
    if (end > (cap - 1))
        end = 0;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::delFront()  {
    if (len <= cap / 4)  {
        decArray();
    }
    len--;
    begin++;
    if (begin > (cap - 1))
        begin = 0;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::delEnd()  {
    if (len <= cap / 4)  {
        decArray();
    }
    end--;
    if (abs(end) != end)  {
        end = cap - 1;
    }
    len--;
}
template <typename elmtype>
int CircularDynamicArray<elmtype>::length()  {
    return len;
}
template <typename elmtype>
int CircularDynamicArray<elmtype>::capacity()  {
    return cap;
}
template <typename elmtype>
int CircularDynamicArray<elmtype>::incArray()  {
    elmtype *newArray = new elmtype[cap * 2];
    for (int i = 0; i < len; i++)  {
        newArray[i] = this -> array[(begin + i) % cap];
    }
    cap = cap * 2;
    delete[] array;
    this -> array = newArray;
    begin = 0;
    end = len - 1;
    return len;
}
template <typename elmtype>
int CircularDynamicArray<elmtype>::decArray()  {
    elmtype *newArray = new elmtype[cap / 2];
    for (int i = 0; i < len; i++)  {
        newArray[i] = this -> array[(begin + i) % cap];
    }
    cap = cap / 2;
    delete[] array;
    this -> array = newArray;
    begin = 0;
    end = len - 1;
    return len;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::clear()  {
    delete[] array;
    this -> len = 0;
    this -> cap = 2;
    this -> array = new elmtype[this -> cap];
}