#include <iostream>
#include <bits/stdc++.h>
using namespace std;
template <typename keytype, typename valuetype>
class BHeap  {
public:
	struct BinomialNode  {
		int place;
		BinomialNode *parent;
		BinomialNode *child;
		BinomialNode *sib;
		keytype key;
		valuetype value;
	};
	list<BinomialNode *> begin;
	BHeap()  {
	}
	BHeap(keytype k[], valuetype V[], int s)  {
		for (int i = 0; i < s; i++)  {
			insert(k[i], V[i]);
		}
	}
	~BHeap()  {
		begin.clear();
	}
	keytype peakKey()  {
		return getMin(this -> begin) -> key;
	}
	valuetype peakValue()  {
		return getMin(this -> begin) -> value;
	}
	keytype extractMin()  {
		list<BinomialNode *> src;
		BinomialNode *node = getMin(this -> begin);
		keytype min = node -> key;
		for (typename list<BinomialNode *>::iterator i = this -> begin.begin(); i != this -> begin.end(); i++)  {
			if (*i == node)  {
				continue;
			}
			src.push_back(*i);
		}
		src = unionFunction(src, removeMinTree(node));
		this -> begin = reorder(src);
		return min;
	}
	void merge(BHeap<keytype, valuetype> &H2)  {
		this -> begin = unionFunction(this -> begin, H2.begin);
		this -> begin = reorder(this -> begin);
	}
	BinomialNode *getMin(list<BinomialNode *> begin)  {
		typename list<BinomialNode *>::iterator i = begin.begin();
		BinomialNode *src = *i;
		for (; i != begin.end(); i++)  {
			if ((*i) -> key < src -> key)  {
				src = *i;
			}
		}
		return src;
	}
	void printNodes(BinomialNode *node)  {
		while (node != NULL)  {
			cout << node -> key << " ";
			printNodes(node -> child);
			node = node -> sib;
		}
	}
	void printKey()  {
		typename list<BinomialNode *>::iterator i;
		for (i = this -> begin.begin(); i != this -> begin.end(); i++)  {
			cout << "B" << (*i) -> place << endl;
			printNodes(*i);
			if (i != this -> begin.end())  {
				cout << endl;
			}
			cout << endl;
		}
	}
	void insert(keytype k, valuetype v)  {
		BinomialNode *newNode = new BinomialNode;
		newNode -> key = k;
		newNode -> value = v;
		newNode -> place = 0;
		newNode -> parent = nullptr;
		newNode -> child = nullptr;
		newNode -> sib = nullptr;
		list<BinomialNode *> node;
		node.push_back(newNode);
		this -> begin = unionFunction(this -> begin, node);
		this -> begin = reorder(this -> begin);
	}
	list<BinomialNode *> removeMinTree(BinomialNode *tree)  {
		list<BinomialNode *> begin;
		BinomialNode *temp = tree -> child;
		BinomialNode *src;
		while (temp)  {
			src = temp;
			temp = temp -> sib;
			src -> sib = nullptr;
			begin.push_front(src);
		}
		return begin;
	}
	list<BinomialNode *> unionFunction(list<BinomialNode *> first, list<BinomialNode *> second)  {
		list<BinomialNode *> unionFunction;
		typename list<BinomialNode *>::iterator tmpIterator, secIterator;
		tmpIterator = first.begin();
		secIterator = second.begin();
		while (tmpIterator != first.end() && secIterator != second.end())  {
			if ((*tmpIterator) -> place <= (*secIterator) -> place)  {
				unionFunction.push_back(*tmpIterator);
				tmpIterator++;
			}
			else  {
				unionFunction.push_back(*secIterator);
				secIterator++;
			}
		}
		while (secIterator != second.end())  {
			unionFunction.push_back(*secIterator);
			secIterator++;
		}
		while (tmpIterator != first.end())  {
			unionFunction.push_back(*tmpIterator);
			tmpIterator++;
		}
		return unionFunction;
	}
	BinomialNode *mergeFunction(BinomialNode *first, BinomialNode *second)  {
		if (first -> key > second -> key)  {
			BinomialNode *src = first;
			first = second;
			second = src;
		}
		second -> parent = first;
		second -> sib = first -> child;
		first -> child = second;
		first -> place = first -> place + 1;
		return first;
	}
	list<BinomialNode *> reorder(list<BinomialNode *> begin)  {
		if (begin.size() <= 1)  {
			return begin;
		}
		typename list<BinomialNode *>::iterator first = begin.begin();
		typename list<BinomialNode *>::iterator second = begin.begin();
		typename list<BinomialNode *>::iterator third = begin.begin();
		if (begin.size() == 2)  {
			second++;
			third = begin.end();
		}
		else  {
			second++;
			third++;
			third++;
		}
		while (second != begin.end())  {
			if (second == begin.end())  {
				first++;
			}
			else if ((*first) -> place < (*second) -> place)  {
				first++;
				second++;
				if (third != begin.end())  {
					third++;
				}
			}
			else if (third != begin.end() && (*first) -> place == (*second) -> place && (*second) -> place == (*third) -> place)  {
				first++;
				second++;
				third++;
			}
			else if ((*first) -> place == (*second) -> place)  {
				*first = mergeFunction(*first, *second);
				second = begin.erase(second);
				if (third != begin.end())  {
					third++;
				}
			}
		}
		return begin;
	}
private:
};
