#include "CircularDynamicArray.cpp"
using namespace std;
template <class keytype, class valuetype>
class Heap  {
public:
	Heap();
	Heap(keytype k[], valuetype V[], int s);
	~Heap();
	void reorder(int i);
	void reorder(keytype k[], valuetype V[], int len, int i);
	void printKey();
	void insert(keytype k, valuetype v);
	valuetype peakValue();
	keytype peakKey();
	keytype extractMin();
private:
	int len;
	CircularDynamicArray<keytype> key;
	CircularDynamicArray<valuetype> val;
};
template <typename keytype, typename valuetype>
Heap<keytype, valuetype>::Heap()  {
	len = 0;
}
template <typename keytype, typename valuetype>
Heap<keytype, valuetype>::Heap(keytype k[], valuetype V[], int s)  {
	len = s;
	valuetype tmpVal[s];
	keytype tmpKey[s];
	for (int i = 0; i < s; i++)  {
		tmpVal[i] = V[i];
		tmpKey[i] = k[i];
	}
	for (int i; i >= 0; i--)  {
		reorder(tmpKey, tmpVal, s, i);
	}

	for (int i = 0; i < s; i++)  {
		this -> key.addEnd(tmpKey[i]);
		this -> val.addEnd(tmpVal[i]);
	}
}
template <typename keytype, typename valuetype>
Heap<keytype, valuetype>::~Heap()  {
	len = 0;
}
template <typename keytype, typename valuetype>
void Heap<keytype, valuetype>::reorder(int i)  {
	int min = i;
	int left = (2 * i) + 1;
	int right = (2 * i) + 2;
	if (right < len && this -> key[right] < this -> key[min])
		min = right;
	if (left < len && this -> key[left] < this -> key[min])
		min = left;
	if (min != i)  {
		keytype tempKey = this -> key[i];
		this -> key[i] = this -> key[min];
		this -> key[min] = tempKey;
		valuetype tempValue = this -> val[i];
		this -> val[i] = this -> val[min];
		this -> val[min] = tempValue;
		reorder(min);
	}
}
template <typename keytype, typename valuetype>
void Heap<keytype, valuetype>::reorder(keytype k[], valuetype V[], int len, int i)  {
	int min = i;
	int left = (2 * i) + 1;
	int right = (2 * i) + 2;
	if (left < len && k[left] < k[min])  {
		min = left;
	}
	if (right < len && k[right] < k[min])  {
		min = right;
	}
	if (min != i)  {
		keytype tempKey = k[i];
		k[i] = k[min];
		k[min] = tempKey;
		valuetype tempValue = V[i];
		V[i] = V[min];
		V[min] = tempValue;
		reorder(k, V, len, min);
	}
}
template <typename keytype, typename valuetype>
void Heap<keytype, valuetype>::printKey()  {
	for (int i = 0; i < len; i++)  {
		cout << this -> key[i] << " ";
	}
	cout << "\n";
}
template <typename keytype, typename valuetype>
void Heap<keytype, valuetype>::insert(keytype k, valuetype v)  {
	len++;
	this -> key.addEnd(k);
	this -> val.addEnd(v);
	for (int i = len - 1;
		(i != 0) && (this -> key[(i - 1) / 2] > k); i = ((i - 1) / 2))  {
		keytype tmp = this -> key[i];
		this -> key[i] = this -> key[(i - 1) / 2];
		this -> key[(i - 1) / 2] = tmp;
		valuetype newTmp = this -> val[i];
		this -> val[i] = this -> val[(i - 1) / 2];
		this -> val[(i - 1) / 2] = newTmp;
	}
}
template <typename keytype, typename valuetype>
valuetype Heap<keytype, valuetype>::peakValue()  {
	return this -> val[0];
}
template <typename keytype, typename valuetype>
keytype Heap<keytype, valuetype>::peakKey()  {
	return this -> key[0];
}
template <typename keytype, typename valuetype>
keytype Heap<keytype, valuetype>::extractMin()  {
	if (len == 1)  {
		keytype newKey = this -> key[0];
		this -> key.delFront();
		this -> val.delFront();
		len--;
		return newKey;
	}
	keytype begin = this -> key[0];
	this -> key[0] = this -> key[len - 1];
	len--;
	reorder(0);
	return begin;
}