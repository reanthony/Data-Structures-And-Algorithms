#include <iostream>
using namespace std;
template <typename keytype, typename valuetype>
class Node  {
private:
    valuetype val;
    keytype key;
    Node *right;
    Node *left;
    int cast;
public:
    Node(keytype key, valuetype val)  {
        this -> right = NULL;
        this -> left = NULL;
        this -> key = key;
        this -> val = val;
        this -> cast = 1; 
    }
    
    Node(const Node &src)  {
        this -> key = src -> key;
        this -> val = src -> val;
        this -> right = src -> right;
        this -> left = src -> left;
        this -> cast = src -> val;
        valuetype getValue();
        valuetype *getValuePointer();
        keytype getKey();
        Node *getRight();
        Node *getLeft();
        int getcast();
        void setRight(Node *right);
        void setLeft(Node *left);
        void setKey(keytype key);
        void setValue(valuetype val);
        void setcast(int cast);

    };
    Node &operator=(const Node &src)  {
        this -> right = src -> right;
        this -> left = src -> left;
        this -> key = src -> key;
        this -> val = src -> val;
        this -> cast = src -> val;
        return *this;
    }
    Node *getRight()  {
        return this -> right;
    }
    Node *getLeft()  {
        return this -> left;
    }
    keytype getKey()  {
        return key;
    }
    int getcast()  {
        return cast;
    }
    void setRight(Node *right)  {
        this -> right = right;
    }
    void setLeft(Node *left)  {
        this -> left = left;
    }
    void setKey(keytype key)  {
        this -> key = key;
    }
    void setValue(valuetype val)  {
        this -> val = val;
    }
    void setcast(int cast)  {
        this -> cast = cast;
    }
    valuetype getValue()  {
        return val;
    }
    valuetype *getValuePointer()  {
        return &val;
    }
    ~Node()  {
        delete right;
        delete left;
    }
};
template <typename keytype, typename valuetype>
class RBTree  {
public:
    RBTree()  {
        base = NULL;
       x= 0;
    }
    RBTree(keytype *k, valuetype *v, int s)  {
        base = NULL;
       x= 0;
        for (int i = 0; i < s; i++)  {
            this -> insert(k[i], v[i]);
        }
    }
    RBTree &operator=(const RBTree &src)  {
        this ->x= src -> x;
        this -> base = src -> x;
        return *this;
    }
    RBTree(const RBTree &src)  {
        this ->x= src -> x;
        this -> base = src -> x;
    }
    ~RBTree()  {
        removeNode(base);
    }
        void invertcast(Node<keytype, valuetype> *base)  {
        if (base -> getcast() == 1)
            base -> setcast(2);
        else
            base -> setcast(1);
    }
    Node<keytype, valuetype> *moveRedRight(Node<keytype, valuetype> *base)  {
        castFlip(base);
        if (isRed(base -> getLeft() -> getLeft()))  {
            base = rotateRight(base);
            castFlip(base);
        }
        return base;
    }
    Node<keytype, valuetype> *moveRedLeft(Node<keytype, valuetype> *base)  {
        castFlip(base);
        if (isRed(base -> getRight() -> getLeft()))  {
            base -> setRight(rotateRight(base -> getRight()));
            base = rotateLeft(base);
            castFlip(base);
        }
        return base;
    }
    void castFlip(Node<keytype, valuetype> *base)  {
        invertcast(base);
        invertcast(base -> getLeft());
        invertcast(base -> getRight());
    }
    Node<keytype, valuetype> *removeFunction(Node<keytype, valuetype> *base, keytype k, int &removed)  {
        if (k < base -> getKey())  {
            if (!isRed(base -> getLeft()) && !isRed(base -> getLeft() -> getLeft()))  {
                base = moveRedLeft(base);
            }
            base -> setLeft(removeFunction(base -> getLeft(), k, removed));
        }
        else  {
            if (isRed(base -> getLeft()))  {
                base = rotateRight(base);
            }
            if (k == base -> getKey() && base -> getRight() == NULL)  {
                removed = 1;
                return base;
            }
            if (!isRed(base -> getRight()) && !isRed(base -> getRight() -> getLeft()))  {
                removed = 1;
                base = moveRedRight(base);
            }
            if (k == base -> getKey())  {
                base -> setValue(get(base -> getRight(), min(base -> getRight())));
                base -> setKey(min(base -> getRight()));
                base -> setRight(deleteMin(base -> getRight()));
            }
            else  {
                base -> setRight(removeFunction(base -> getRight(), k, removed));
            }
        }
        return fixUp(base);
    }
    void deleteMin()  {
        base = deleteMin(base);
        base -> setcast(2);
    }
    Node<keytype, valuetype> *deleteMin(Node<keytype, valuetype> *base)  {
        if (base -> getLeft() == NULL)  {
            return NULL;
        }
        if (!isRed(base -> getLeft()) && !isRed(base -> getLeft() -> getLeft()))  {
            base = moveRedLeft(base);
        }
        base -> setLeft(deleteMin(base -> getLeft()));
        return fixUp(base);
    }
    Node<keytype, valuetype> *fixUp(Node<keytype, valuetype> *base)  {
        if (isRed(base -> getRight()))  {
            base = rotateLeft(base);
        }
        if (isRed(base -> getLeft()) && isRed(base -> getLeft() -> getLeft()))
            base = rotateRight(base);
        if (isRed(base -> getLeft()) && isRed(base -> getRight()))
            castFlip(base);
        return base;
    }
    keytype min(Node<keytype, valuetype> *base)  {
        if (base -> getLeft() == NULL)  {
            return base -> getKey();
        }
        else  {
            return min(base -> getLeft());
        }
    }
    valuetype get(keytype key)  {
        return get(base, key);
    }
    valuetype get(Node<keytype, valuetype> *base, keytype key)  {
        if (base == NULL)  {
            return 0;
        }
        if (key == base -> getKey())  {
            return base -> getValue();
        }
        if (key < base -> getKey())  {
            return get(base -> getLeft(), key);
        }
        else  {
            return get(base -> getRight(), key);
        }
    }
void inorderFunction(Node<keytype, valuetype> *base)  {
        if (base)  {
            this -> inorderFunction(base -> getLeft());
            cout << base -> getKey() << " ";
            this -> inorderFunction(base -> getRight());
        }
    }
void preorderFunction(Node<keytype, valuetype> *base)  {
        if (base != NULL)  {
            cout << base -> getKey() << " ";
            this -> preorderFunction(base -> getLeft());
            this -> preorderFunction(base -> getRight());
        }
    }
void postorderFunction(Node<keytype, valuetype> *base)  {
        if (base != NULL)  {
            this -> postorderFunction(base -> getLeft());
            this -> postorderFunction(base -> getRight());
            cout << base -> getKey() << " ";
        }
    }
    void removeNode(Node<keytype, valuetype> *base)  {
        if (base)  {
            removeNode(base -> getLeft());
            removeNode(base -> getRight());
            delete base;
        }
    }
    valuetype *search(keytype k)  {
        valuetype *val = new valuetype();
        searchFunction(base, k, val);
        return val;
    }
    void searchFunction(Node<keytype, valuetype> *base, keytype key, valuetype *val)  {
        if (base)  {
            this -> searchFunction(base -> getLeft(), key, val);
            if (base -> getKey() == key)  {
                *val = base -> getValue();
            }
            this -> searchFunction(base -> getRight(), key, val);
        }
    }
    void insert(keytype k, valuetype v)  {
        base = insertFunction(this -> base, k, v);
        base -> setcast(2);
        x++;
    }
    Node<keytype, valuetype> *rotateLeft(Node<keytype, valuetype> *node)  {
        Node<keytype, valuetype> *child = node -> getRight();
        Node<keytype, valuetype> *leftChild = child -> getLeft();
        child -> setLeft(node);
        node -> setRight(leftChild);
        return child;
    }
    Node<keytype, valuetype> *rotateRight(Node<keytype, valuetype> *base)  {
        Node<keytype, valuetype> *child = base -> getLeft();
        Node<keytype, valuetype> *rightChild = child -> getRight();
        child -> setRight(base);
        base -> setLeft(rightChild);
        return child;
    }
    void swapcasts(Node<keytype, valuetype> *a, Node<keytype, valuetype> *b)  {
        int temp = a -> getcast();
        a -> setcast(b -> getcast());
        b -> setcast(temp);
    }
    bool isRed(Node<keytype, valuetype> *base)  {
        if (base == NULL)  {
            return false;
        }
        return base -> getcast() == 1;
    }
    Node<keytype, valuetype> *insertFunction(Node<keytype, valuetype> *base, keytype key, valuetype val)  {
        if (base == NULL)  {
            return new Node<keytype, valuetype>(key, val);
        }
        if (key < base -> getKey())  {
            Node<keytype, valuetype> *node = insertFunction(base -> getLeft(), key, val);
            base -> setLeft(node);
        }
        else if (key > base -> getKey())  {
            base -> getRight();
            Node<keytype, valuetype> *node = insertFunction(base -> getRight(), key, val);
            base -> setRight(node);
        }
        else  {
            return base;
        }
        if (isRed(base -> getRight()) && !isRed(base -> getLeft()))  {
            base = this -> rotateLeft(base);
            this -> swapcasts(base, base -> getLeft());
        }
        if (isRed(base -> getLeft()) && isRed(base -> getLeft() -> getLeft()))  {
            base = this -> rotateRight(base);
            this -> swapcasts(base, base -> getRight());
        }
        if (isRed(base -> getLeft()) && isRed(base -> getRight()))  {
            if (base -> getcast() == 1)  {
                base -> setcast(2);
            }
            else  {
                base -> setcast(1);
            }
            base -> getRight() -> setcast(2);
            base -> getLeft() -> setcast(2);
        }
        return base;
    }
    int rank(keytype k)  {
        int rank = 0;
        int idx = 0;
        rankFunction(base, idx, rank, k);
        return rank;
    }
    void rankFunction(Node<keytype, valuetype> *base, int &idx, int &rank, keytype key)  {
        if (base)  {
            this -> rankFunction(base -> getLeft(), idx, rank, key);
            idx++;
            if ((keytype)base -> getKey() == key)  {
                rank = idx;
            }
            this -> rankFunction(base -> getRight(), idx, rank, key);
        }
    }
    keytype select(int pos)  {
        keytype *sorted = new keytype[x];
        int idx = 0;
        getSorted(base, idx, sorted);
        if (pos < 1 && pos > x)  {
            return 0;
        }
        return sorted[pos - 1];
    }
    void getSorted(Node<keytype, valuetype> *base, int &idx, keytype *sorted)  {
        if (base)  {
            this -> getSorted(base -> getLeft(), idx, sorted);
            sorted[idx] = base -> getKey();
            idx++;
            this -> getSorted(base -> getRight(), idx, sorted);
        }
    }
    void split(keytype k, RBTree &T1, RBTree &T2)  {
        splitFunction(base, k, T1, T2);
    }
    void splitFunction(Node<keytype, valuetype> *base, keytype k, RBTree &T1, RBTree &T2)  {
        if (base)  {
            this -> splitFunction(base -> getLeft(), k, T1, T2);
            if (base -> getKey() == k)  {
                T2.base = base -> getRight();
                T1.base = base -> getLeft();
            }
            this -> splitFunction(base -> getRight(), k, T1, T2);
        }
    }
    int size()  {
        return this -> x;
    }
    void inorder()  {
        this -> inorderFunction(this -> base);
        cout << endl;
    }
    void preorder()  {
        this -> preorderFunction(base);
        cout << endl;
    }
    void postorder()  {
        this -> postorderFunction(this -> base);
        cout << endl;
    }
    int remove(keytype k)  {
        int removed = 0;
        int rank = 0;
        int idx = 0;
        rankFunction(base, idx, rank, k);
        if (rank != 0)  {
            base = removeFunction(base, k, removed);
            base -> setcast(2);
        }
        return removed;
    }
private:
    Node<keytype, valuetype> *base;
    int x;
};