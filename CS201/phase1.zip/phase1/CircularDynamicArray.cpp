#include <iostream>
using namespace std;
template <typename elmtype>
class CircularDynamicArray  {
private:
    int len;
    int cap;
    elmtype *array;
    elmtype *arr;
public:
    CircularDynamicArray(const CircularDynamicArray &src);
    CircularDynamicArray();
    elmtype& operator[](int i);
    CircularDynamicArray(int s);
    ~CircularDynamicArray();
    void addFront(elmtype v);
    void addEnd(elmtype v);
    void delFront();
    void delEnd();
    void incArray();
    void decArray();
    void clear();
    int length();
    int capacity();
    void stableSort();
    void mergeSort(int l, int r);
    void merge(int l, int m, int r);
    void radixSort(int i);
    void radixFunction(elmtype *arr, int i);
    int posFunction();
    elmtype QuickSelect(int k);
    elmtype qsFunction(int l, int r, int p);
    elmtype WCSelect(int k);
    elmtype kthSmallest(elmtype arr[], int l, int r, int k);
    void swap(elmtype *a, elmtype *b);
    int partition(elmtype arr[], int l, int r, int  num);
    elmtype findMedian(int l, int n);
    int binSearch(elmtype e);
    int binFunction(int l, int r, elmtype  num);
    int linearSearch(elmtype e);
    CircularDynamicArray &operator=(const CircularDynamicArray &src)  {
        this->len = src.len;
        this->cap = src.cap;
        this->array = new elmtype[this->cap];
        for (int i = 0; i < src.len; i++)  {
            this->array[i] = src.array[i];
        }
        return *this;
    }
};
template <typename elmtype>
CircularDynamicArray<elmtype>::CircularDynamicArray(const CircularDynamicArray &src)  {
    this->len = src.len;
    this->cap = src.cap;
    this->array = new elmtype[this->cap];
    for (int i = 0; i < src.len; i++)  {
        this->array[i] = src.array[i];
    }
}
template <typename elmtype>
CircularDynamicArray<elmtype>::CircularDynamicArray()  {
    this->len = 0;
    this->cap = 2;
    this->array = new elmtype[this->cap];
}
template <typename elmtype>
elmtype &CircularDynamicArray<elmtype>::operator[](int i)  {
    if (i >= 0 && i < len)  {
        return array[i];
    }
    cout << "Out of bounds reference : " << i << endl;
    return *arr;
}
template <typename elmtype>
CircularDynamicArray<elmtype>::CircularDynamicArray(int s)  {
    this->len = s;
    this->cap = s;
    this->array = new elmtype[this->cap];
}
template <typename elmtype>
CircularDynamicArray<elmtype>::~CircularDynamicArray()  {
    delete[] this->array;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::addFront(elmtype v)  {
    if (len == cap)  {
        incArray();
    }
    for (int i = len - 1; i >= 0; --i)  {
        array[i + 1] = array[i];
    }
    array[0] = v;
    len++;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::addEnd(elmtype v)  {
    if (len == cap) 
        incArray();
    array[len] = v;
    len++;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::delFront()  {
    for (int i = 0; i < len - 1; i++)  {
        array[i] = array[i + 1];
    }
    len--;
    if (len < (cap / 4)) 
        decArray();
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::delEnd()  {
    len--;
    if (len < (cap / 4))  {
        decArray();
    }
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::incArray()  {
    elmtype *newArray = new elmtype[this->cap * 2];
    for (int i = 0; i < this->len; i++)  {
        newArray[i] = array[i];
    }
    delete[] array;
    this->cap = this->cap * 2;
    array = newArray;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::decArray()  {
    elmtype *newArray = new elmtype[this->cap / 2];
    for (int i = 0; i < this->len; i++)  {
        newArray[i] = array[i];
    }
    delete[] array;
    this->cap = this->cap / 2;
    array = newArray;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::clear()  {
    delete[] array;
    this->len = 0;
    this->cap = 2;
    this->array = new elmtype[this->cap];
}
template <typename elmtype>
int CircularDynamicArray<elmtype>::length()  {
    return this->len;
}

template <typename elmtype>
int CircularDynamicArray<elmtype>::capacity()  {
    return this->cap;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::stableSort()  {
    this->mergeSort(0, this->len - 1);
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::mergeSort(int l, int r)  {
    if (l < r)  {
        int m = l + (r - l) / 2;
        mergeSort(l, m);
        mergeSort(m + 1, r);
        merge(l, m, r);
    }
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::merge(int l, int m, int r)  {
    int i = 0;
    int j = 0;
    int nums = m - l + 1;
    int rest = r - m;
    elmtype *left = new elmtype[nums];
    elmtype *right = new elmtype[rest];
    for (i = 0; i < nums; i++)
        left[i] = this->array[l + i];
    for (j = 0; j < rest; j++)
        right[j] = this->array[m + 1 + j];
    i = 0;
    j = 0;
    int f = l;
    while (i < nums && j < rest)  {
        if (left[i] > right[j])  {
            this->array[f] = right[j];
            j++;
        }
        else  {
            this->array[f] = left[i];
            i++;
        }
        f++;
    }
    for (; i < nums; i++, f++)  {
        this->array[f] = left[i];
    }
    for (; j < rest; j++, f++)  {
        this->array[f] = right[j];
    }
    delete[] left;
    delete[] right;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::radixSort(int i)  {
    int pos = this->posFunction();
    int neg = len - pos;
    int negIdx = 0;
    int posIdx = 0;
    elmtype *posArray = new elmtype[pos];
    elmtype *negArray = new elmtype[neg];
    for (int j = 0; j < this->len; j++)  {
        if (this->array[j] >= 0)  {
            posArray[posIdx++] = this->array[j];
        }
        else  {
            negArray[negIdx++] = this->array[j] * -1;
        }
    }
    this->radixFunction(negArray, neg);
    int z = 0;
    for (int j = neg - 1; j >= 0; j--)  {
        this->array[z++] = negArray[j] * -1;
    }
    delete[] negArray;
    this->radixFunction(posArray, pos);
    for (int j = 0; j < pos; j++)  {
        this->array[z++] = posArray[j];
    }
    delete[] posArray;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::radixFunction(elmtype *arr, int n)  {
    int  min = -99999999;
    for (int i = 0; i < n; i++)  {
        if (arr[i] >  min)  {
             min = arr[i];
        }
    }
    elmtype *newArr = new elmtype[n];
    for (int  num = 1;  min /  num > 0;  num *= 10)  {
        int i, base[10] = {0};
        for (i = 0; i < n; i++)  {
            int idx = (arr[i] /  num) % 10;
            if (idx < 0)  {
                idx = idx * -1;
            }
            base[idx]++;
        }
        for (i = 1; i < 10; i++)  {
            base[i] += base[i - 1];
        }
        for (i = n - 1; i >= 0; i--)  {
            int idx = (arr[i] /  num) % 10;
            if (idx < 0)  {
                idx = idx * -1;
            }
            newArr[base[idx] - 1] = arr[i];
            base[idx]--;
        }
        for (i = 0; i < n; i++)  {
            arr[i] = newArr[i];
        }
    }
    delete[] newArr;
}
template <typename elmtype>
int CircularDynamicArray<elmtype>::posFunction()  {
    int base = 0;
    for (int i = 0; i < this->len; i++)  {
        if (this->array[i] >= 0)
            base++;
    }
    return base;
}
template <typename elmtype>
elmtype CircularDynamicArray<elmtype>::QuickSelect(int k)  {
    return qsFunction(0, (this->length() - 1), k);
}
template <typename elmtype>
elmtype CircularDynamicArray<elmtype>::qsFunction(int l, int r, int p)  {
    if (p > 0 && p <= r - l + 1)  {
        int idx;
        int  num = this->array[r];
        int i = l;
        for (int j = l; j <= r - 1; j++)  {
            if (this->array[j] <=  num)  {
                int tmp = this->array[i];
                this->array[i] = this->array[j];
                this->array[j] = tmp;
                i++;
            }
        }
        int tmp = this->array[i];
        this->array[i] = this->array[r];
        this->array[r] = tmp;
        idx = i;
        if (idx - l == p - 1)
            return this->array[idx];
        if (idx - l > p - 1)
            return qsFunction(l, idx - 1, p);
        return qsFunction(idx + 1, r, p - idx + l - 1);
    }
    return -1;
}
template <typename elmtype>
elmtype CircularDynamicArray<elmtype>::WCSelect(int k)  {
    return this->kthSmallest(this->array, 0, (this->length() - 1), k);
}
template <typename elmtype>
elmtype CircularDynamicArray<elmtype>::kthSmallest(elmtype arr[], int l, int r, int k)  {
    if (k > 0 && k <= r - l + 1)  {
        int n = r - l + 1;
        int i;
        elmtype median[(n + 4) / 5];
        for (i = 0; i < n / 5; i++)
            median[i] = findMedian(l + i * 5, 5);
        if (i * 5 < n)  {
            median[i] = findMedian(l + i * 5, n % 5);
            i++;
        }
        elmtype medOfMed = (i == 1) ? median[i - 1] : kthSmallest(median, 0, i - 1, i / 2);
        int pos = partition(arr, l, r, medOfMed);
        if (pos - l == k - 1)
            return arr[pos];
        if (pos - l > k - 1) 
            return kthSmallest(arr, l, pos - 1, k);
        return kthSmallest(arr, pos + 1, r, k - pos + l - 1);
    }
    return -1;
}
template <typename elmtype>
void CircularDynamicArray<elmtype>::swap(elmtype *a, elmtype *b)  {
    elmtype tmp = *a;
    *a = *b;
    *b = tmp;
}
template <typename elmtype>
int CircularDynamicArray<elmtype>::partition(elmtype arr[], int l, int r, int  num)  {
    int i;
    for (i = l; i < r; i++)
        if (arr[i] ==  num)
            break;
    swap(&arr[i], &arr[r]);
    i = l;
    for (int j = l; j <= r - 1; j++)  {
        if (arr[j] <=  num)  {
            swap(&arr[i], &arr[j]);
            i++;
        }
    }
    swap(&arr[i], &arr[r]);
    return i;
}
template <typename elmtype>
elmtype CircularDynamicArray<elmtype>::findMedian(int l, int n)  {
    this->mergeSort(l, n);
    return this->array[l + (n / 2)]; 
}
template <typename elmtype>
int CircularDynamicArray<elmtype>::binSearch(elmtype e)  {
    return this->binFunction(0, this->len - 1, e);
}
template <typename elmtype>
int CircularDynamicArray<elmtype>::binFunction(int l, int r, elmtype e)  {
    if (r >= l)  {
        int m = l + (r - l) / 2;
        if (this->array[m] == e)
            return m;
        if (this->array[m] > e)
            return binFunction(l, m - 1, e);
        return binFunction(m + 1, r, e);
    }
    return -1;
}
template <typename elmtype>
int CircularDynamicArray<elmtype>::linearSearch(elmtype e)  {
    for (int i = 0; i < this->len; i++)  {
        if (this->array[i] == e)  {
            return i;
        }
    }
    return -1;
}